angular.module('models', [
	'models.message',
	'models.user',
  'rest.diagrams',
  'rest.joblist'
]);